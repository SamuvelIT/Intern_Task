import React from 'react'
import Hi from './components/Hi.jsx'
import Login from './components/Login.jsx'
import Register from './components/Register.jsx'
function App() {
  return (
    <>
    <div className='main h-screen bg-blue-300'>

      <Hi data='Hiii React Developers!!!'/>
      <div className='flex flex-row'>
        <Login data1='Login Form'/> 
         <Register data2='Register Form'/>
      </div>
    </div>
    </>
    
  )
}

export default App