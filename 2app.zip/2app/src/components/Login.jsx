

export default function Login({data1}) {
  return (
    <div>
        <div className="m-30 ml-50 w-70 bg-gray-600 h-70 rounded-2xl ">
            <div className="flex flex-col items-center justify-center  pt-10 gap-y-5 ">
                {data1}
            <input className="bg-white rounded-2xl" type="name" placeholder="  Enter your name" />
            <input className="bg-white rounded-2xl" type="email" placeholder="  Enter your email" />
            <button className="bg-blue-900 rounded-xl h-10 w-20" type="submit">Login</button>
            </div>
        </div>
    </div>
  )
}
