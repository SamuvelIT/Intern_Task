
export default function Register({data2}) {
  return (
    <div>
        <div className="m-30 ml-70 w-70 bg-orange-300 h-70 rounded-2xl ">
            <div className="flex flex-col items-center justify-center  pt-10 gap-y-5 ">
                {data2}
            <input className="bg-white rounded-2xl" type="name" placeholder="  Enter your name" />
            <input className="bg-white rounded-2xl" type="email" placeholder="  Enter your email" />
            <button className="bg-yellow-400 rounded-xl h-10 w-20" type="submit">Register</button>
            </div>
        </div>
    </div>
  )
}
