

export default function Hi({data}) {
  return (
    <div className="text-3xl font-bold flex justify-center p-10 bg-white rounded-4xl" >
        {data}
    </div>
  )
}
